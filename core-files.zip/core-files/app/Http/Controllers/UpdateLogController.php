<?php

namespace App\Http\Controllers;

use App\Model\UpdateLog;
use Illuminate\Http\Request;
use Auth;

class UpdateLogController extends Controller
{
    public function index(){
        $logs = UpdateLog::where('company_id',Auth::user()->company_id)->orderBy('id','asc')->get();
        return view('admin.update-log.index')->with([
            'logs'   => $logs
        ]);
    }

    public function store(Request $request){
        $this->validate($request,[
            'name'  => 'required',
        ]);
        UpdateLog::create($request->only('device_id'));
        return redirect()->back()->withMessage([
            'status'    => true,
            'text'      => 'Successfully created device.'
        ]);
    }
    public function delete($id){
        UpdateLog::where([
            'company_id'    => Auth::user()->company_id,
            'id'            => $id
        ])->delete();
        return redirect()->back()->withMessage([
            'status'    => true,
            'text'      => 'Successfully deleted region.'
        ]);
    }
}
