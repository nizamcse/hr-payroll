<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class AttendanceLog extends Model
{
    protected $fillable = ['employee_id','device_employee_id','machine_id','logging_time','company_id'];
}
