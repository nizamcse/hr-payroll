<?php

namespace App\Model;

use App\Traits\CompanyTrait;
use Illuminate\Database\Eloquent\Model;

class UpdateLog extends Model
{
    use CompanyTrait;
    protected $fillable = ['device_id'];

    public function device(){
        return $this->belongsTo('App\Model\Device','device_id','id');
    }
}
