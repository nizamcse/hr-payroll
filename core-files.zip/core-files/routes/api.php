<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('zk',function(Request $request){
    return [
        'status'    => 200,
        'message'   => 'Company Id '.$request->CompanyId. " successfully connected with the server."
    ];
});


Route::post('zk/saveGeneralLogs/{companyId}/{accessToken}',function(Request $request,$companyId,$acessToken){
    $logs = $request->all();
    foreach ($logs as $k => $log){
        if($k >= 50)
            break;
        $company = \App\Model\Company::where('company_id',$companyId)->first();
        \App\Model\AttendanceLog::create([
            'device_employee_id'    => $log['IndRegID'],
            'machine_id'    => $log['MachineNumber'],
            'logging_time'  => \Carbon\Carbon::parse($log['DateTimeRecord'])->format('Y-m-d h:m:s'),
            'company_id'    => $company->id ?? null
        ]);
    }
    return [
        'status'    => 200,
        'message'   => "Successfully synced the logs."
    ];
});