<?php


Route::group(['middleware' => ['auth','super.admin']],function(){

    Route::get('/companies',[
        'uses'  => 'CompanyController@index',
        'as'    => 'companies'
    ]);


    Route::post('/create-company',[
        'uses'  => 'CompanyController@store',
        'as'    => 'store-company'
    ]);

    Route::get('/edit-company/{id}',[
        'uses'  => 'CompanyController@edit',
        'as'    => 'edit-company'
    ]);

    Route::post('/update-company/{id}',[
        'uses'  => 'CompanyController@update',
        'as'    => 'update-company'
    ]);

    Route::get('/delete-company/{id}',[
        'uses'  => 'CompanyController@delete',
        'as'    => 'delete-company'
    ]);


    Route::post('/update/company/user/password/{id}',[
        'uses'  => 'CompanyController@updateOrCreateAdmin',
        'as'    => 'update-company-user-pass'
    ]);

    Route::get('/update/company/user/password/{id}',function($id){
        $user = \App\User::where('company_id',$id)->where('company_admin',true)->first();
        return response()->json($user);
    });


    /**
     * Find Existing User
     */

    Route::post('/search/user',[
        'uses'  => 'CompanyController@findUser',
        'as'    => 'search-user'
    ]);
});

Route::group(['middleware' => ['auth']], function () {
    /**
     * Designation
     */
    Route::get('/', function () {
        return view('welcome');
    });

    Route::get('/designations', [
        'uses' => 'DesignationController@index',
        'as' => 'designations'
    ]);

    Route::get('/designation/{id}', function ($id) {
        $designation = \App\Model\Designation::where([
            'company_id'    => \Illuminate\Support\Facades\Auth::user()->company_id,
            'id'            => $id
        ])->first();
        return response()->json($designation, 200);
    })->name('designation');

    Route::post('/designation/{id}', [
        'uses' => 'DesignationController@update',
        'as' => 'update-designation'
    ]);

    Route::post('/designation', [
        'uses' => 'DesignationController@store',
        'as' => 'create-designation'
    ]);

    Route::get('/delete-designation/{id}', [
        'uses' => 'DesignationController@delete',
        'as' => 'delete-designation'
    ]);

    /**
     * Deduction Type
     */

    Route::get('/deduction-types', [
        'uses' => 'DeductionTypeController@index',
        'as' => 'deduction-types'
    ]);

    Route::get('/deduction-type/{id}', function ($id) {
        $deduction_type = \App\Model\DeductionType::where([
            'company_id'    => \Illuminate\Support\Facades\Auth::user()->company_id,
            'id'            => $id
        ])->first();
        return response()->json($deduction_type, 200);
    })->name('deduction-type');

    Route::post('/deduction-type/{id}', [
        'uses' => 'DeductionTypeController@update',
        'as' => 'update-deduction-type'
    ]);

    Route::post('/deduction-type', [
        'uses' => 'DeductionTypeController@store',
        'as' => 'create-deduction-type'
    ]);

    Route::get('/delete-deduction-type/{id}', [
        'uses' => 'DeductionTypeController@delete',
        'as' => 'delete-deduction-type'
    ]);

    /**
     * Bonus
     */

    Route::get('/bonuses', [
        'uses' => 'BonusController@index',
        'as' => 'bonuses'
    ]);

    Route::get('/bonus/{id}', function ($id) {
        $bonus = \App\Model\Bonus::where([
            'company_id'    => \Illuminate\Support\Facades\Auth::user()->company_id,
            'id'            => $id
        ])->first();
        return response()->json($bonus, 200);
    })->name('bonus');

    Route::post('/bonus/{id}', [
        'uses' => 'BonusController@update',
        'as' => 'update-bonus'
    ]);

    Route::post('/bonus', [
        'uses' => 'BonusController@store',
        'as' => 'create-bonus'
    ]);

    Route::get('/delete-bonus/{id}', [
        'uses' => 'BonusController@delete',
        'as' => 'delete-bonus'
    ]);


    /**
     * Leave Type
     */
    Route::get('/leave-types', [
        'uses' => 'LeaveTypeController@index',
        'as' => 'leave-types'
    ]);

    Route::get('/leave-type/{id}', function ($id) {
        $leave_type = \App\Model\LeaveType::where([
            'company_id'    => \Illuminate\Support\Facades\Auth::user()->company_id,
            'id'            => $id
        ])->first();
        return response()->json($leave_type, 200);
    })->name('leave-type');

    Route::post('/leave-type/{id}', [
        'uses' => 'LeaveTypeController@update',
        'as' => 'update-leave-type'
    ]);

    Route::post('/leave-type', [
        'uses' => 'LeaveTypeController@store',
        'as' => 'create-leave-type'
    ]);

    Route::get('/delete-leave-type/{id}', [
        'uses' => 'LeaveTypeController@delete',
        'as' => 'delete-leave-type'
    ]);

    /**
     * Create Vacation Calender
     */

    Route::get('/vacations',[
        'uses'  => 'VacationController@index',
        'as'    => 'vacations'
    ]);

    Route::get('/create/vacation',[
        'uses'  => 'VacationController@create',
        'as'    => 'create-vacation'
    ]);

    Route::post('/create/vacation',[
        'uses'  => 'VacationController@store',
        'as'    => 'store-vacation'
    ]);

    Route::get('/edit/vacation/{id}',[
        'uses'  => 'VacationController@edit',
        'as'    => 'edit-vacation'
    ]);

    Route::post('/edit/vacation/{id}',[
        'uses'  => 'VacationController@update',
        'as'    => 'update-vacation'
    ]);

    Route::get('/delete/vacation/{id}',[
        'uses'  => 'VacationController@delete',
        'as'    => 'delete-vacation'
    ]);

    /**
     * Section
     */
    Route::get('/sections', [
        'uses' => 'SectionController@index',
        'as' => 'sections'
    ]);

    Route::get('/section/{id}', function ($id) {
        $section = \App\Model\Section::where([
            'company_id'    => \Illuminate\Support\Facades\Auth::user()->company_id,
            'id'            => $id
        ])->first();
        return response()->json($section, 200);
    })->name('section');

    Route::post('/section/{id}', [
        'uses' => 'SectionController@update',
        'as' => 'update-section'
    ]);

    Route::post('/section', [
        'uses' => 'SectionController@store',
        'as' => 'create-section'
    ]);

    Route::get('/delete-section/{id}', [
        'uses' => 'SectionController@delete',
        'as' => 'delete-section'
    ]);

    /**
     * Branch
     */
    Route::get('/branches', [
        'uses' => 'BranchController@index',
        'as' => 'branches'
    ]);

    Route::get('/branch/{id}', function ($id) {
        $section = \App\Model\Branch::where([
            'company_id'    => \Illuminate\Support\Facades\Auth::user()->company_id,
            'id'            => $id
        ])->first();
        return response()->json($section, 200);
    })->name('branch');

    Route::post('/branch/{id}', [
        'uses' => 'BranchController@update',
        'as' => 'update-branch'
    ]);

    Route::post('/branch', [
        'uses' => 'BranchController@store',
        'as' => 'create-branch'
    ]);

    Route::get('/delete-branch/{id}', [
        'uses' => 'BranchController@delete',
        'as' => 'delete-branch'
    ]);

    /**
     * Lines
     */
    Route::get('/lines', [
        'uses' => 'LineController@index',
        'as' => 'lines'
    ]);

    Route::get('/line/{id}', function ($id) {
        $section = \App\Model\Line::where([
            'company_id'    => \Illuminate\Support\Facades\Auth::user()->company_id,
            'id'            => $id
        ])->first();
        return response()->json($section, 200);
    })->name('line');

    Route::post('/line/{id}', [
        'uses' => 'LineController@update',
        'as' => 'update-line'
    ]);

    Route::post('/line', [
        'uses' => 'LineController@store',
        'as' => 'create-line'
    ]);

    Route::get('/delete-line/{id}', [
        'uses' => 'LineController@delete',
        'as' => 'delete-line'
    ]);

    /**
     * Employee
     */

    Route::get('/employees',[
        'uses'  => 'EmployeeController@index',
        'as'    => 'employees'
    ]);

    Route::get('/employee',[
        'uses'  => 'EmployeeController@create',
        'as'    => 'create-employee'
    ]);

    Route::post('/employee',[
        'uses'  => 'EmployeeController@store',
        'as'    => 'store-employee'
    ]);

    Route::get('/employee/{id}',[
        'uses'  => 'EmployeeController@employee',
        'as'    => 'show-employee'
    ]);

    Route::get('/edit/employee/{id}',[
        'uses'  => 'EmployeeController@edit',
        'as'    => 'edit-employee'
    ]);

    Route::post('/update/employee/{id}',[
        'uses'  => 'EmployeeController@update',
        'as'    => 'update-employee'
    ]);

    Route::get('/delete/employee/{id}',[
        'uses'  => 'EmployeeController@delete',
        'as'    => 'delete-employee'
    ]);

    /**
     * Device
     */
    Route::get('/devices', [
        'uses' => 'DeviceController@index',
        'as' => 'devices'
    ]);

    Route::get('/device/{id}', function ($id) {
        $section = \App\Model\Device::where([
            'company_id'    => \Illuminate\Support\Facades\Auth::user()->company_id,
            'id'            => $id
        ])->first();
        return response()->json($section, 200);
    })->name('device');

    Route::post('/device/{id}', [
        'uses' => 'DeviceController@update',
        'as' => 'update-device'
    ]);

    Route::post('/device', [
        'uses' => 'DeviceController@store',
        'as' => 'create-device'
    ]);

    Route::get('/delete-device/{id}', [
        'uses' => 'DeviceController@delete',
        'as' => 'delete-device'
    ]);

    /**
     * Update Log
     */
    Route::get('/update-logs', [
        'uses' => 'UpdateLogController@index',
        'as' => 'update-logs'
    ]);

    Route::post('/update-log', [
        'uses' => 'UpdateLogController@store',
        'as' => 'create-update-log'
    ]);

    Route::get('/delete-update-log/{id}', [
        'uses' => 'UpdateLogController@delete',
        'as' => 'delete-update-log'
    ]);



    /**
     * Logout
     */

    Route::get('/logout',function(){
        Auth::logout();
        return redirect()->route('login');
    })->name('logout');

});



Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
